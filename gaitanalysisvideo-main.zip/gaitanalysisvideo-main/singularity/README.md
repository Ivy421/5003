## External Files Not Included:
  - cmake-3.25.0-rc2-linux-x86_64 (https://cmake.org/files/PreviousRelease/cmake-3.25.0-rc2-linux-x86_64.tar.gz)
  - pose_iter_584000.caffemodel
  - body_25b/pose_iter_XXXXXX.caffemodel (https://github.com/CMU-Perceptual-Computing-Lab/openpose_train/blob/master/experimental_models/README.md)
  - body_25b/pose_deploy.prototxt
  - /root/setup_mediapipe/pose_landmark_lite.tflite (https://storage.googleapis.com/mediapipe-assets/pose_landmark_lite.tflite)
  - /root/setup_mediapipe/pose_landmark_heavy.tflite (https://storage.googleapis.com/mediapipe-assets/pose_landmark_heavy.tflite)
  - /data/openpose/pose_landmarker.task (https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_heavy/float16/latest/pose_landmarker_heavy.task)

Checksum:
2600805362 47889677 cmake-3.25.0-rc2-linux-x86_64.tar.gz
3354577589 104715850 ./openpose/models/pose/body_25/pose_iter_584000.caffemodel
686093014 106928170 ./openpose/models/pose/body_25b/pose_iter_XXXXXX.caffemodel
3046200362 73763 ./openpose/models/pose/body_25b/pose_deploy.prototxt
1712465520 2819824 /root/setup_mediapipe/pose_landmark_lite.tflite
2506546807 27709200 /root/setup_mediapipe/pose_landmark_heavy.tflite
228362420 30664242 /data/openpose/pose_landmarker.task

